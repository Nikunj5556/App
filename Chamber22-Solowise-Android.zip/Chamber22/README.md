# Chamber 22 — Made by Solowise
Native Android inquiry desk for Advocate Sharad Kumar Saxena, Bareilly.

## What is included
- Kotlin + Jetpack Compose (not a WebView).
- Warm ivory, forest green, muted gold, serif headlines and custom scales icon.
- Private email/password sign-in with encrypted session storage and token refresh.
- Clearly labelled sample-data mode; call and WhatsApp disabled in demo.
- Live Supabase inquiry inbox matching the supplied website: name, phone, email,
  metadata.matter_type, preferred_time, language and created_at.
- Paginated REST loading of all inquiries, newest first, search and status filters.
- New / Contacted / Closed status controls and full detail bottom sheet.
- WhatsApp prefilled greeting and Android dialer (no CALL_PHONE permission).
- Notification permission request, notification settings shortcut, channel,
  Firebase token registration/refresh and foreground notification service.
- Supabase database webhook -> Edge Function -> Firebase HTTP v1 push for background alerts.
- Generic notification previews without names, numbers or legal matter details.
- 30-second inbox refresh while this screen is composed; explicit refresh as well.
- Chamber information and Made by Solowise branding.

## Build and run
1. Install Android Studio, JDK 17, Android SDK 35. Open this folder as a Gradle project.
2. Use Gradle 8.9. The binary Gradle wrapper is not bundled. If needed, install Gradle
   8.9 and run `gradle wrapper --gradle-version 8.9` from this folder, then sync.
3. Run on Android 8+ (API 26+). Use the login screen's Explore the design option to
   inspect sample data immediately; Firebase configuration is not needed for demo.
4. Build > Build App Bundle(s) / APK(s) > Build APK(s). For release, configure your
   own signing key and keep it outside source control.

No APK is supplied and this source has NOT been compiled or device-tested in the
creation environment. Resolve any dependency/SDK compatibility issues in Android
Studio before distribution. This is an implementation handoff, not a deployed service.

## Supabase setup — required for live data
Existing website project: https://sdsfgqhebohsjcpqxaei.supabase.co
Tenant: sharad-kumar-saxena. The website's public anon key is in Repository.kt.
It is not a service-role credential. Never ship a service-role key in an Android app.

1. Back up the database and inspect the existing inquiries schema, policies and grants.
   The HTML shows the insert payload, not the live database schema. The migration
   expects inquiries.id and created_at. Match these if your existing schema differs.
2. Review `supabase/migrations/001_chamber.sql` on staging, then run it in SQL Editor.
   WARNING: it replaces ALL inquiry RLS policies for a single-client deployment.
   Do not run unchanged on a shared/multi-client project. Adapt the membership rules
   and public-insert policy to preserve other clients first. It also revokes existing
   anon/authenticated grants on inquiries and limits updates to the status column.
   Existing per-column grants should also be audited in an established database.
3. In Supabase Authentication create the advocate's user (email + strong password).
   There is intentionally no public sign-up UI. Disable public signups if not needed.
4. Add membership with an administrator SQL session (replace the UUID):
   INSERT INTO public.chamber_members(user_id,client_id)
   VALUES ('YOUR_AUTH_USER_UUID','sharad-kumar-saxena');
5. Sign into the app. New inquiries should load. Verify an unrelated user sees none.
6. Confirm website submissions still succeed. The supplied website payload uses
   matter types criminal/marriage/civil/other and times any/morning/afternoon/evening.

## Firebase push setup — required for notifications
1. Create/open a Firebase project. Register Android package com.solowise.chamber22.
2. Download google-services.json to app/google-services.json. This file is deliberately
   not fabricated. The build applies Google Services only when the file exists.
3. Enable Firebase Cloud Messaging HTTP v1 API in the matching Google Cloud project.
4. Create a service account credential authorized to send FCM messages in this project.
   Store it on the server only; never put it in app assets or source control.
5. Link Supabase CLI to this project and deploy the function:
   supabase functions deploy notify-inquiry --no-verify-jwt
   JWT verification is disabled only because this webhook authenticates using its
   own high-entropy secret header. Do NOT omit that secret.
6. Set function secrets through Supabase Dashboard / CLI:
   INQUIRY_WEBHOOK_SECRET = a long randomly generated secret
   FIREBASE_SERVICE_ACCOUNT_JSON = the complete service-account JSON object
   SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are normally supplied automatically.
7. In Supabase Database > Webhooks create an INSERT webhook on public.inquiries:
   URL: https://sdsfgqhebohsjcpqxaei.supabase.co/functions/v1/notify-inquiry
   Method: POST
   Headers: Content-Type: application/json
            x-webhook-secret: exactly the same random secret
   Send the default database webhook JSON (type, schema, table, record, old_record).
8. Rebuild/run the app, sign in and tap the bell or Settings > Enable inquiry notifications.
   On Android 13+ the native permission prompt appears; denial is respected. On older
   Android versions check the OS notification switch. Token registration happens at
   login/startup and token refresh, including after granting permission.
9. Submit an inquiry from the real website. Verify foreground and background delivery.
   Notifications open the inbox, not a specific inquiry. Refresh fetches current data.

## Delivery limitations / operations
FCM delivery is not guaranteed or instantaneous. Network/battery settings, permission,
Google Play services and Android force-stop can prevent/delay alerts. Opening the app
again after force-stop may be necessary. Polling is not the background push mechanism.
Webhook requests can fail and webhook retries may duplicate alerts. This implementation
is best-effort: production-critical operation should add an outbox with durable retries,
idempotency keyed to inquiry/device, monitoring and alerts. The function reports failed
sends and removes tokens explicitly reported as UNREGISTERED; it does not log personal
information. It sends only to current chamber members and re-fetches the inquiry server-side.

The public website still posts directly using an anon key. RLS restricts inserts, but
for public abuse prevention add a server-side form endpoint, CAPTCHA and rate limiting;
a browser-side cooldown is not sufficient protection. Review retention/access requirements
for inquiry data and apply your operational security policy before launch.

## Acceptance checklist
[ ] Android Studio sync + debug/release build succeeds
[ ] No Google Services file: demo opens; Settings accurately states push unconfigured
[ ] Wrong credentials show an error; unauthorized user cannot read other tenants
[ ] Website insert works and fields map correctly; null email renders safely
[ ] Multiple pages (>500 rows) load; search/status filters work
[ ] WhatsApp opens visitor chat and Call opens dialer (neither auto-sends nor auto-calls)
[ ] Status update persists after refresh; unauthorized update is blocked
[ ] Android 13+: allow and deny tested; settings shortcut works
[ ] Firebase token registers and rotates; sign-out unregisters device best-effort
[ ] Foreground, background, offline and force-stop behavior tested on a real device
[ ] Webhook secret failure returns 401; unknown inquiry cannot trigger a valid notification
[ ] Removed chamber membership no longer receives new notifications
[ ] TalkBack, font scaling, smaller displays and Hindi names checked

No database, Firebase project, webhook, account or external service was modified while
creating this source archive. Configure and verify those steps in your own environment.
