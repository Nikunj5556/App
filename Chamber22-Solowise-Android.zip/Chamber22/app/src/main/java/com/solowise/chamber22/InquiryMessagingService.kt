package com.solowise.chamber22
import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.*
class InquiryMessagingService:FirebaseMessagingService(){
 override fun onNewToken(token:String){val job=CoroutineScope(SupervisorJob()+Dispatchers.IO);job.launch{try{val repo=Repository(applicationContext);if(repo.signedIn)repo.register(token)}finally{job.cancel()}}}
 override fun onMessageReceived(message:RemoteMessage){
  if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
  val intent=Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
  val pending=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  val notification=NotificationCompat.Builder(this,"inquiries").setSmallIcon(com.solowise.chamber22.R.drawable.ic_notification).setContentTitle("New chamber inquiry").setContentText("A new callback request is ready in your private inbox.").setContentIntent(pending).setAutoCancel(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).build()
  getSystemService(NotificationManager::class.java).notify((message.messageId?:System.currentTimeMillis().toString()).hashCode(),notification)
 }
}
