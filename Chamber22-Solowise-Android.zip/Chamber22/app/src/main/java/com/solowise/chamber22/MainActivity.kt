package com.solowise.chamber22

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

val Pine=Color(0xFF193E35)
val Gold=Color(0xFFC7A66A)
val Paper=Color(0xFFF8F6F0)
val Ink=Color(0xFF202E29)
val Muted=Color(0xFF788078)
val Demo=listOf(
 Inquiry("demo1","Aarav Sharma","+919876543210","aarav@example.com","criminal","morning","hi",OffsetDateTime.now().minusMinutes(12).toString(),"new"),
 Inquiry("demo2","Priya Verma","+919876543211","","marriage","evening","en",OffsetDateTime.now().minusHours(1).toString(),"new"),
 Inquiry("demo3","Mohammad Faizan","+919876543212","","civil","afternoon","hi",OffsetDateTime.now().minusHours(3).toString(),"contacted"),
 Inquiry("demo4","Neha Singh","+919876543213","","other","any","hi",OffsetDateTime.now().minusDays(1).toString(),"closed")
)
fun matter(s:String)=when(s){"criminal"->"Criminal law";"marriage","court_marriage"->"Court marriage";"civil"->"Civil matter";else->s.replaceFirstChar{it.uppercase()}}
fun stamp(s:String)=runCatching{OffsetDateTime.parse(s).atZoneSameInstant(ZoneId.of("Asia/Kolkata")).format(DateTimeFormatter.ofPattern("dd MMM · h:mm a"))}.getOrDefault(s)
class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("inquiries","New inquiries",NotificationManager.IMPORTANCE_HIGH).apply{description="Callback requests from your chamber website";lockscreenVisibility=android.app.Notification.VISIBILITY_PRIVATE})
  setContent { MaterialTheme(colorScheme=lightColorScheme(primary=Pine,secondary=Gold,background=Paper,surface=Color.White,onPrimary=Color.White,onBackground=Ink,onSurface=Ink),typography=Typography()){ChamberApp()} }
 }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ChamberApp(){
 val ctx=LocalContext.current;val scope=rememberCoroutineScope();val repo=remember{Repository(ctx)}
 var signed by remember{mutableStateOf(repo.signedIn)};var demo by remember{mutableStateOf(false)}
 var list by remember{mutableStateOf(emptyList<Inquiry>())};var loading by remember{mutableStateOf(false)}
 var error by remember{mutableStateOf<String?>(null)};var selected by remember{mutableStateOf<Inquiry?>(null)}
 var query by remember{mutableStateOf("")};var filter by remember{mutableStateOf("All")};var tab by remember{mutableStateOf(0)}
 var email by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
 var saving by remember{mutableStateOf(false)}
 val snack=remember{SnackbarHostState()}
 suspend fun refresh(){loading=true;try{list=if(demo)Demo else repo.list();error=null}catch(e:Exception){error=e.message}finally{loading=false}}
 suspend fun register(){if(!demo&&FirebaseApp.getApps(ctx).isNotEmpty())runCatching{repo.register(FirebaseMessaging.getInstance().token.await())}.onFailure{snack.showSnackbar("Push setup incomplete. See Settings.")}}
 val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){allowed->scope.launch{snack.showSnackbar(if(allowed)"Inquiry alerts enabled" else "Alerts are off. You can enable them in Settings.");if(allowed)register()}}
 fun enableAlerts(){if(Build.VERSION.SDK_INT>=33)permission.launch(Manifest.permission.POST_NOTIFICATIONS) else scope.launch{register();snack.showSnackbar("Check notification settings to allow alerts.")}}
 LaunchedEffect(signed,demo){if(signed||demo){refresh();register();while(true){delay(30000);refresh()}}}
 Scaffold(containerColor=Paper,snackbarHost={SnackbarHost(snack)},bottomBar={if(signed||demo)NavigationBar(containerColor=Color.White,tonalElevation=0.dp){listOf("Inquiries" to Icons.Outlined.Inbox,"Chamber" to Icons.Outlined.AccountBalance,"Settings" to Icons.Outlined.Settings).forEachIndexed{i,p->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(p.second,p.first)},label={Text(p.first)})}}}){padding->
 if(!signed&&!demo){
 Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(28.dp),verticalArrangement=Arrangement.spacedBy(20.dp)){
 Spacer(Modifier.height(38.dp));Emblem();Text("CHAMBER 22",letterSpacing=4.sp,color=Pine,fontSize=12.sp,fontWeight=FontWeight.Bold)
 Text("A considered way\nto stay connected.",fontFamily=FontFamily.Serif,fontSize=36.sp,lineHeight=42.sp,color=Ink)
 Text("The private inquiry desk of\nAdvocate Sharad Kumar Saxena",color=Muted,lineHeight=24.sp)
 OutlinedTextField(email,{email=it},label={Text("Chamber email")},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
 OutlinedTextField(password,{password=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
 error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
 Button(onClick={scope.launch{busy=true;try{repo.login(email.trim(),password);password="";signed=true;error=null}catch(e:Exception){error=e.message}finally{busy=false}}},enabled=!busy&&email.isNotBlank()&&password.isNotBlank(),modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){if(busy)CircularProgressIndicator(Modifier.size(22.dp),color=Color.White,strokeWidth=2.dp)else Text("Open your inquiry desk   →")}
 TextButton(onClick={demo=true;list=Demo}){Text("Explore the design · demo data")}
 Text("Private access only. Ask your administrator to create your chamber account.",color=Muted,fontSize=12.sp)
 Brand()
 }
 }else{
 Column(Modifier.fillMaxSize().padding(padding)){
 Row(Modifier.fillMaxWidth().padding(horizontal=24.dp,vertical=18.dp),verticalAlignment=Alignment.CenterVertically){Emblem(44);Column(Modifier.weight(1f).padding(start=12.dp)){Text("CHAMBER 22",fontSize=11.sp,letterSpacing=3.sp,color=Pine,fontWeight=FontWeight.Bold);Text("Sharad Kumar Saxena",fontFamily=FontFamily.Serif,fontSize=18.sp)};IconButton(onClick={enableAlerts()}){Icon(Icons.Outlined.Notifications,"Enable notifications",tint=Pine)}}
 if(demo)Text("DESIGN PREVIEW · Sample inquiries, not live client data",Modifier.fillMaxWidth().background(Color(0xFFF0E5CB)).padding(10.dp),fontSize=11.sp,color=Pine)
 when(tab){
 0->{
 LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(start=22.dp,end=22.dp,bottom=24.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
 item{Column{Text("Your inquiry desk",fontFamily=FontFamily.Serif,fontSize=32.sp);Text("Every conversation starts with attention.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=6.dp))}}
 item{Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Pine,Color(0xFF2E5748)))).padding(23.dp)){
 Column{Text("AWAITING YOUR ATTENTION",color=Color(0xFFD7C89E),fontSize=10.sp,letterSpacing=2.sp);Row(verticalAlignment=Alignment.Bottom){Text(list.count{it.status=="new"}.toString().padStart(2,'0'),fontFamily=FontFamily.Serif,fontSize=58.sp,color=Color.White);Text(" new inquiries",color=Color(0xFFDCE7DD),modifier=Modifier.padding(bottom=13.dp,start=10.dp))};HorizontalDivider(color=Color.White.copy(alpha=.17f));Row(Modifier.fillMaxWidth().padding(top=16.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("${list.size} received",color=Color.White,fontSize=12.sp);Text("${list.count{it.status=="contacted"}} contacted",color=Color.White,fontSize=12.sp);Text("${list.count{it.status=="closed"}} closed",color=Color.White,fontSize=12.sp)}}}}
 item{OutlinedTextField(query,{query=it},placeholder={Text("Search name, phone or matter")},leadingIcon={Icon(Icons.Outlined.Search,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))}
 item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("All","New","Contacted","Closed").forEach{v->FilterChip(selected=filter==v,onClick={filter=v},label={Text(v)})}}}
 item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("RECENT INQUIRIES",letterSpacing=2.sp,fontSize=10.sp,color=Muted,fontWeight=FontWeight.Bold);TextButton(onClick={scope.launch{refresh()}}){Text(if(loading)"Refreshing…" else "Refresh ↻")}}}
 error?.let{e->item{Text(e,color=MaterialTheme.colorScheme.error);TextButton(onClick={scope.launch{refresh()}}){Text("Try again")}}}
 val filtered=list.filter{(filter=="All"||it.status.equals(filter,true))&&("${it.name} ${it.phone} ${matter(it.matter)}".contains(query,true))}
 if(filtered.isEmpty()&&!loading)item{Column(Modifier.fillMaxWidth().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Outlined.Inbox,null,Modifier.size(40.dp),tint=Gold);Text(if(list.isEmpty())"A quiet desk, for now." else "No matching inquiries",fontFamily=FontFamily.Serif,fontSize=23.sp);Text("New website requests will appear here.",color=Muted,fontSize=12.sp)}}
 items(filtered,key={it.id}){q->InquiryCard(q,demo,onOpen={selected=q})}
 item{Text("All received requests · Times in IST",fontSize=10.sp,color=Muted);Spacer(Modifier.height(16.dp));Brand()}
 }
 }
 1->Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(22.dp)){
 Text("The chamber",fontSize=34.sp,fontFamily=FontFamily.Serif)
 Surface(shape=RoundedCornerShape(24.dp),color=Pine){Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Icon(Icons.Outlined.AccountBalance,null,tint=Gold,modifier=Modifier.size(40.dp));Text("Advocate\nSharad Kumar Saxena",fontFamily=FontFamily.Serif,fontSize=28.sp,color=Color.White);Text("अधिवक्ता शरद कुमार सक्सेना",color=Color(0xFFE3D5B2));Text("Chamber No. 22 · Civil Lines, Bareilly",color=Color.White,fontSize=12.sp)}}
 Text("Chamber No. 22, 1st Floor, B-Block\nUsha Agarwal Smriti Building\nSharab Godam Road / Station Road\nCivil Lines, Bareilly · 243001",lineHeight=26.sp,color=Muted)
 Text("Criminal law  /  Court marriage  /  Civil matters",fontSize=13.sp,color=Pine)
 Text("Near Kutchery Post Office",color=Muted);Brand()
 }
 2->Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(20.dp)){
 Text("A little more control.",fontSize=32.sp,fontFamily=FontFamily.Serif)
 Text("INQUIRY ALERTS",letterSpacing=2.sp,fontSize=11.sp,color=Muted)
 Text("Be notified when a new request reaches the chamber. Notification previews never include personal details.",color=Muted)
 Button(onClick={enableAlerts()},modifier=Modifier.fillMaxWidth()){Text("Enable inquiry notifications")}
 OutlinedButton(onClick={ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,ctx.packageName))},modifier=Modifier.fillMaxWidth()){Text("Open Android notification settings")}
 Text(if(FirebaseApp.getApps(ctx).isEmpty())"Push not configured: add your Firebase google-services.json and deploy the included webhook." else "Firebase configured. Server webhook deployment is also required.",fontSize=12.sp,color=Muted)
 HorizontalDivider();Text("Private by design",fontFamily=FontFamily.Serif,fontSize=23.sp);Text("Only authorized chamber users can access live inquiries. No confidential case details should be entered through the website.",color=Muted,fontSize=13.sp)
 Text("Version 1.0 · Native Android",color=Muted,fontSize=12.sp)
 OutlinedButton(onClick={scope.launch{if(!demo){if(FirebaseApp.getApps(ctx).isNotEmpty())runCatching{repo.unregister(FirebaseMessaging.getInstance().token.await())};repo.logout()};signed=false;demo=false;list=emptyList();selected=null;tab=0;error=null}}){Text(if(demo)"Leave demo" else "Sign out")};Brand()
 }
 }
 }
 }
 }
 selected?.let{q->ModalBottomSheet(onDismissRequest={if(!saving)selected=null},containerColor=Paper){Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
 Text("INQUIRY DETAILS",fontSize=10.sp,letterSpacing=3.sp,color=Muted);Text(q.name,fontFamily=FontFamily.Serif,fontSize=32.sp);Status(q.status)
 Detail("PHONE",q.phone);if(q.email.isNotBlank())Detail("EMAIL",q.email)
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Detail("MATTER",matter(q.matter));Detail("PREFERRED TIME",q.time.replaceFirstChar{it.uppercase()}+" · IST")}
 Detail("RECEIVED",stamp(q.created));Detail("LANGUAGE",if(q.language=="hi")"Hindi" else "English")
 ContactActions(q,demo)
 HorizontalDivider();Text("Update inquiry status",fontFamily=FontFamily.Serif,fontSize=21.sp)
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("new","contacted","closed").forEach{s->FilterChip(enabled=!saving,selected=q.status==s,onClick={scope.launch{saving=true;try{if(!demo)repo.status(q.id,s);list=list.map{if(it.id==q.id)it.copy(status=s)else it};selected=q.copy(status=s)}catch(e:Exception){snack.showSnackbar(e.message?:"Could not update inquiry")}finally{saving=false}}},label={Text(s.replaceFirstChar{it.uppercase()})})}}
 Text("Preferred time is a request, not a confirmed appointment.",fontSize=11.sp,color=Muted);Spacer(Modifier.height(20.dp))
 }}}
}
@Composable fun Emblem(size:Int=56){Box(Modifier.size(size.dp).clip(RoundedCornerShape(16.dp)).background(Pine),contentAlignment=Alignment.Center){Icon(Icons.Outlined.Balance,null,tint=Gold,modifier=Modifier.size((size*.55).dp))}}
@Composable fun Brand(){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center){Text("Crafted with care  ·  Made by ",fontSize=11.sp,color=Muted);Text("Solowise",fontSize=11.sp,color=Pine,fontWeight=FontWeight.Bold)}}
@Composable fun Detail(label:String,value:String){Column(verticalArrangement=Arrangement.spacedBy(5.dp)){Text(label,fontSize=10.sp,letterSpacing=1.sp,color=Muted);Text(value,fontSize=15.sp)}}
@Composable fun Status(status:String){Surface(shape=RoundedCornerShape(8.dp),color=when(status){"new"->Color(0xFFEBF1E6);"contacted"->Color(0xFFF3ECD9);else->Color(0xFFEFEEEA)}){Text(status.replaceFirstChar{it.uppercase()},fontSize=10.sp,color=Pine,modifier=Modifier.padding(horizontal=10.dp,vertical=5.dp))}}
@Composable fun InquiryCard(q:Inquiry,demo:Boolean,onOpen:()->Unit){Surface(onClick=onOpen,shape=RoundedCornerShape(20.dp),color=Color.White,border=BorderStroke(1.dp,Color(0xFFE8E9E1))){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
 Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFF0EEE5)),contentAlignment=Alignment.Center){Text(q.name.split(" ").filter{it.isNotEmpty()}.take(2).joinToString(""){it.take(1)},fontFamily=FontFamily.Serif,color=Pine,fontSize=18.sp)};Column(Modifier.weight(1f).padding(start=12.dp)){Text(q.name,fontSize=17.sp,fontFamily=FontFamily.Serif,fontWeight=FontWeight.Medium);Text(matter(q.matter),fontSize=12.sp,color=Muted)};Status(q.status)}
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(stamp(q.created),color=Muted,fontSize=10.sp);Text(q.time.replaceFirstChar{it.uppercase()}+" · IST",color=Muted,fontSize=10.sp)}
 ContactActions(q,demo)
}}}
@Composable fun ContactActions(q:Inquiry,demo:Boolean){val ctx=LocalContext.current
 fun open(whatsapp:Boolean){val digits=q.phone.filter{it.isDigit()};val normalized=if(digits.length==10)"91$digits" else digits;val uri=if(whatsapp)"https://wa.me/$normalized?text="+Uri.encode("Namaste ${q.name}, this is Advocate Sharad Kumar Saxena’s chamber regarding your callback request.") else "tel:+$normalized";runCatching{ctx.startActivity(Intent(if(whatsapp)Intent.ACTION_VIEW else Intent.ACTION_DIAL,Uri.parse(uri)))}}
 Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(enabled=!demo,onClick={open(true)},modifier=Modifier.weight(1f).height(44.dp),shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFEDF5EB),contentColor=Pine)){Icon(Icons.Outlined.ChatBubbleOutline,null,Modifier.size(16.dp));Spacer(Modifier.width(7.dp));Text("WhatsApp",fontSize=12.sp)};OutlinedButton(enabled=!demo,onClick={open(false)},modifier=Modifier.weight(1f).height(44.dp),shape=RoundedCornerShape(12.dp),border=BorderStroke(1.dp,Color(0xFFDFE5DC))){Icon(Icons.Outlined.Call,null,Modifier.size(16.dp));Spacer(Modifier.width(7.dp));Text("Call",fontSize=12.sp)}}
}
