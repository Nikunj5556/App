package com.solowise.chamber22

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

object Config {
 const val URL = "https://sdsfgqhebohsjcpqxaei.supabase.co"
 const val KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNkc2ZncWhlYm9oc2pjcHF4YWVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg3NjUwMTUsImV4cCI6MjEwNDM0MTAxNX0.Xh4vJlR9fzBSdUhwptPc6tcPCeKBiAzkXkzh-Z675Nk"
 const val CLIENT = "sharad-kumar-saxena"
}
data class Inquiry(val id:String,val name:String,val phone:String,val email:String,val matter:String,val time:String,val language:String,val created:String,val status:String) {
 companion object {
  fun parse(j:JSONObject):Inquiry { val m=j.optJSONObject("metadata")?:JSONObject();return Inquiry(j.getString("id"),j.optString("name"),j.optString("phone"),j.optString("email").takeUnless{it=="null"}?:"",m.optString("matter_type","other"),m.optString("preferred_time","any"),m.optString("language","hi"),j.optString("created_at"),j.optString("status","new")) }
 }
}
class Repository(context:Context) {
 private val prefs=EncryptedSharedPreferences.create(context,"session",MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
 private val http=OkHttpClient()
 private val lock=Mutex()
 val signedIn get()=prefs.contains("refresh")
 private suspend fun request(path:String,method:String="GET",body:JSONObject?=null,token:String=Config.KEY):String=withContext(Dispatchers.IO) {
  val b=Request.Builder().url(Config.URL+path).header("apikey",Config.KEY).header("Authorization","Bearer $token")
  if(method!="GET") b.method(method,(body?:JSONObject()).toString().toRequestBody("application/json".toMediaType()))
  http.newCall(b.build()).execute().use { r -> val text=r.body?.string().orEmpty();if(!r.isSuccessful) throw IOException(if(r.code==401) "Your session expired. Sign in again." else "Request failed (${r.code}). Check your connection and chamber access.");text }
 }
 private fun save(j:JSONObject){prefs.edit().putString("access",j.getString("access_token")).putString("refresh",j.getString("refresh_token")).putString("uid",j.getJSONObject("user").getString("id")).putLong("expires",System.currentTimeMillis()+j.optLong("expires_in",3600)*1000).apply()}
 suspend fun login(email:String,password:String){save(JSONObject(request("/auth/v1/token?grant_type=password","POST",JSONObject().put("email",email).put("password",password))))}
 private suspend fun token():String=lock.withLock {if(System.currentTimeMillis()>prefs.getLong("expires",0)-60000){save(JSONObject(request("/auth/v1/token?grant_type=refresh_token","POST",JSONObject().put("refresh_token",prefs.getString("refresh","")!!))))};prefs.getString("access","")!!}
 suspend fun list():List<Inquiry>{val result=mutableListOf<Inquiry>();var offset=0;do{val a=JSONArray(request("/rest/v1/inquiries?client_id=eq.${Config.CLIENT}&select=*&order=created_at.desc,id.desc&limit=500&offset=$offset",token=token()));for(i in 0 until a.length())result.add(Inquiry.parse(a.getJSONObject(i)));offset+=a.length();val more=a.length()==500}while(more);return result.distinctBy{it.id}}
 suspend fun status(id:String,value:String){request("/rest/v1/inquiries?id=eq.$id&client_id=eq.${Config.CLIENT}","PATCH",JSONObject().put("status",value),token())}
 suspend fun register(fcm:String){request("/rest/v1/rpc/register_device","POST",JSONObject().put("p_token",fcm).put("p_client",Config.CLIENT),token())}
 suspend fun unregister(fcm:String){request("/rest/v1/device_tokens?token=eq.$fcm","DELETE",token=token())}
 suspend fun logout(){runCatching{request("/auth/v1/logout","POST",token=token())};prefs.edit().clear().apply()}
}
