import { createClient } from "npm:@supabase/supabase-js@2";
import { importPKCS8, SignJWT } from "npm:jose@5";
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const secret = Deno.env.get("INQUIRY_WEBHOOK_SECRET");
Deno.serve(async req => {
 if(req.method!=="POST")return new Response("Method not allowed",{status:405});
 if(!secret || req.headers.get("x-webhook-secret")!==secret)return new Response("Unauthorized",{status:401});
 try {
 const payload=await req.json();
 if(payload.type!=="INSERT" || payload.table!=="inquiries" || payload.schema!=="public")return new Response("Ignored");
 const record=payload.record;
 // Do not trust the incoming payload as a source of recipient or personal data.
 const {data:row,error:rowError}=await admin.from("inquiries").select("id,client_id").eq("id",record?.id).single();
 if(rowError||!row)return new Response("Unknown inquiry",{status:400});
 const {data:members,error:memberError}=await admin.from("chamber_members").select("user_id").eq("client_id",row.client_id);
 if(memberError)throw memberError;
 const ids=(members??[]).map(m=>m.user_id);
 if(!ids.length)return Response.json({sent:0});
 const {data:devices,error:deviceError}=await admin.from("device_tokens").select("token").eq("client_id",row.client_id).in("user_id",ids);
 if(deviceError)throw deviceError;
 if(!devices?.length)return Response.json({sent:0});
 const sa=JSON.parse(Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON")!);
 const key=await importPKCS8(sa.private_key,"RS256");
 const assertion=await new SignJWT({scope:"https://www.googleapis.com/auth/firebase.messaging"})
 .setProtectedHeader({alg:"RS256",typ:"JWT"}).setIssuer(sa.client_email).setAudience("https://oauth2.googleapis.com/token").setIssuedAt().setExpirationTime("1h").sign(key);
 const auth=await fetch("https://oauth2.googleapis.com/token",{method:"POST",body:new URLSearchParams({grant_type:"urn:ietf:params:oauth:grant-type:jwt-bearer",assertion})});
 if(!auth.ok)throw new Error("FCM authentication failed");
 const {access_token}=await auth.json();
 let sent=0,failed=0;
 // Notification payload lets Android display alerts while app is in background.
 // Generic text deliberately avoids disclosing a visitor's name, number or matter.
 for(const d of devices){
 const response=await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`,{
 method:"POST",headers:{Authorization:`Bearer ${access_token}`,"Content-Type":"application/json"},
 body:JSON.stringify({message:{token:d.token,notification:{title:"New chamber inquiry",body:"A new callback request is ready in your private inbox."},
 android:{priority:"HIGH",notification:{channel_id:"inquiries",tag:String(row.id),visibility:"PRIVATE"}}}})});
 if(response.ok){sent++;continue;}
 failed++;
 const details=await response.json().catch(()=>({}));
 if(details.error?.details?.some((x:{errorCode?:string})=>x.errorCode==="UNREGISTERED"))await admin.from("device_tokens").delete().eq("token",d.token);
 }
 return Response.json({sent,failed},{status:failed?502:200});
 }catch {return new Response("Notification processing failed; inspect server configuration.",{status:500});}
});
