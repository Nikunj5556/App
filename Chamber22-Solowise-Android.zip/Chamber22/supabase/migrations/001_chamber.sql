-- REVIEW on staging first. This single-client setup deliberately replaces inquiry
-- policies. For a multi-tenant production project, adapt existing policies instead.
begin;
create table if not exists public.inquiries (
 id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(),
 name text not null, phone text not null, email text, client_id text not null, metadata jsonb not null default '{}'::jsonb
);
alter table public.inquiries add column if not exists status text not null default 'new';
alter table public.inquiries enable row level security;
create table if not exists public.chamber_members (
 user_id uuid references auth.users(id) on delete cascade,
 client_id text not null, primary key(user_id,client_id)
);
alter table public.chamber_members enable row level security;
revoke all on public.chamber_members from anon,authenticated;
grant select on public.chamber_members to authenticated;
create policy "read own membership" on public.chamber_members for select to authenticated using(user_id=auth.uid());
create table if not exists public.device_tokens (
 token text primary key, user_id uuid not null references auth.users(id) on delete cascade,
 client_id text not null, updated_at timestamptz not null default now()
);
alter table public.device_tokens enable row level security;
revoke all on public.device_tokens from anon,authenticated;
grant select,delete on public.device_tokens to authenticated;
create policy "own devices" on public.device_tokens for select to authenticated using(user_id=auth.uid());
create policy "delete own devices" on public.device_tokens for delete to authenticated using(user_id=auth.uid());
create or replace function public.register_device(p_token text,p_client text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null or not exists(select 1 from public.chamber_members where user_id=auth.uid() and client_id=p_client) then raise exception 'Unauthorized';end if;
 if length(p_token)<20 or length(p_token)>4096 then raise exception 'Invalid token';end if;
 insert into public.device_tokens(token,user_id,client_id) values(p_token,auth.uid(),p_client)
 on conflict(token) do update set user_id=excluded.user_id,client_id=excluded.client_id,updated_at=now();
end;$$;
revoke all on function public.register_device(text,text) from public,anon;
grant execute on function public.register_device(text,text) to authenticated;
-- Existing permissive policies could expose personal data; replace only after review.
do $$ declare p record;begin
 for p in select policyname from pg_policies where schemaname='public' and tablename='inquiries' loop
 execute format('drop policy %I on public.inquiries',p.policyname);
 end loop;
end $$;
revoke all on public.inquiries from anon,authenticated;
grant insert(name,phone,email,client_id,metadata) on public.inquiries to anon;
grant select on public.inquiries to authenticated;
grant update(status) on public.inquiries to authenticated;
create policy "website callback insert" on public.inquiries for insert to anon with check (
 client_id='sharad-kumar-saxena' and status='new' and
 length(name) between 2 and 100 and phone ~ '^\+91[6-9][0-9]{9}$' and
 metadata->>'consent'='true' and metadata->>'source'='advocate-website' and
 metadata->>'matter_type' in ('criminal','marriage','civil','other') and
 metadata->>'preferred_time' in ('any','morning','afternoon','evening')
);
create policy "members read inquiries" on public.inquiries for select to authenticated using (
 exists(select 1 from public.chamber_members m where m.user_id=auth.uid() and m.client_id=inquiries.client_id)
);
create policy "members update status" on public.inquiries for update to authenticated using (
 exists(select 1 from public.chamber_members m where m.user_id=auth.uid() and m.client_id=inquiries.client_id)
) with check(status in ('new','contacted','closed') and exists(select 1 from public.chamber_members m where m.user_id=auth.uid() and m.client_id=inquiries.client_id));
create index if not exists inquiries_client_created on public.inquiries(client_id,created_at desc);
commit;
